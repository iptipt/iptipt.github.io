package nexp1;
import java.io.*;
import java.util.*;


public class Nexp1 {
static
{
    System.load("C:\\Users\\anant\\Documents\\NetBeansProjects\\CNexp1\\output\\jniout1.dll");
}
        public static void main(String[] args) {
            Scanner s=new Scanner(System.in);
            int count=10;
            count = s.nextInt();
            Nexp1 jni = new Nexp1();
            int res = jni.Increment(count);
            System.out.println("Count "+ res);
        // TODO code application logic here
    }
    private native int Increment(int count);

}
