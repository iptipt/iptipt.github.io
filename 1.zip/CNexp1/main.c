#include <stdio.h>
#include <stdlib.h>
#include <jni.h>
#include "head.h"
JNIEXPORT jint JNICALL Java_nexp1_Nexp1_Increment
  (JNIEnv *env, jobject jobj, jint count)
{
    return count*10;
}

