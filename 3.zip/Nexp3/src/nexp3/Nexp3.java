/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nexp3;
public class Nexp3 {
      static
    {
        System.load("C:\\Users\\anant\\Documents\\NetBeansProjects\\CNexp3\\output\\exp3.dll");
    }
    private native void catchThrow() throws IllegalArgumentException;
  private void callback() throws NullPointerException {
    throw new NullPointerException("thrown in CatchThrow.callback");
  }

    public static void main(String[] args) {
              Nexp3 c = new Nexp3();
    try {
      c.catchThrow();
    } catch (Exception e) {
      System.out.println("In Java:\n  " + e);
    }
  }
}
    

