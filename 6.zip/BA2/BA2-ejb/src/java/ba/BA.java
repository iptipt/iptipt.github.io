package ba;
import javax.ejb.Stateful;
@Stateful
public class BA implements BALocal {
    private int balance = 0;
    @Override
    public void withDraw(int amount) {
        if(balance >= amount)
        {
            balance = balance-amount;
        }
    }
    @Override
    public void deposit(int amount) {
        balance+=amount;
    }
    @Override
    public int balance() {
        return balance;
    }
}
