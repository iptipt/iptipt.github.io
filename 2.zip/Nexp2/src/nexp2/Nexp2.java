package nexp2;
import java.io.*;
import java.util.*;

public class Nexp2 {
    static
    {
        System.load("C:\\Users\\anant\\Documents\\NetBeansProjects\\CNexp2\\output\\exp2.dll");
    }

    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n;
        n=s.nextInt();
        int[] b=new int[20];
        for(int i=1;i<=n;i++)
            b[i]=s.nextInt();
        Nexp2 sd=new Nexp2();
        sd.sorting(b,n);
        // TODO code application logic here
    }
    private native void sorting(int[] b,int n);

 }
    

