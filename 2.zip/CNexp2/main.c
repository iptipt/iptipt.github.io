#include <stdio.h>
#include <stdlib.h>
#include <jni.h>
#include "head.h"
JNIEXPORT void JNICALL Java_nexp2_Nexp2_sorting
  (JNIEnv *env, jobject job, jintArray b, jint n) {
 
    int i,j,temp;
    jint *p=(*env)->GetIntArrayElements(env,b,NULL);
    for(i=1;i<n;i++)
    {
        for(j=i+1;j<=n;j++)
        {
            if(p[i]>p[j])
            {
                temp=p[i];
                p[i]=p[j];
                p[j]=temp;
            }
        }
    }
    for(i=1;i<=n;i++)
        printf("%d\n",p[i]);
    
}
