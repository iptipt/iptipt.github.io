package shop;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import javax.ejb.Stateful;
@Stateful
public class ShopBean implements ShopBeanLocal {
    private String Items="";
    @Override
    public void addItem(String parameter) {
        Items = Items+ " " + parameter;
    }
    @Override
    public String delItem() {
        String tmp;
        tmp = "Thank you for buying these items ->  " + Items;
        Items="";
        return tmp;
    }
}
