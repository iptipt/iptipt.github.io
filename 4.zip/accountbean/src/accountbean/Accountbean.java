
package accountbean;

public class Accountbean
{
    int balance;

    public Accountbean()
    {
        balance =0;
    }
    public void deposit(int amount)
    {
        if(amount>0)
            balance += amount;
    }
    public void withdraw(int amount)
    {
        balance -= amount;
    }
    public int checkBalance()
    {
        return balance;
    }
    
}
