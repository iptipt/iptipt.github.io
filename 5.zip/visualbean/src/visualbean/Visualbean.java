package visualbean;
import static java.awt.Color.red;
import javax.swing.JLabel;

public class Visualbean extends JLabel
{
    public Visualbean()
    {
        setText("Visual Bean");
        setBounds(50,100,100,30);
        setVisible(true);
        setForeground(red);
    }
    
}
